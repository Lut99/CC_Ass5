/*! \mainpage VirusGame
 *
 * Documentation extracted from the source code by Doxygen.
 * See the <a href="annotated.html">list of classes</a>.
 */
